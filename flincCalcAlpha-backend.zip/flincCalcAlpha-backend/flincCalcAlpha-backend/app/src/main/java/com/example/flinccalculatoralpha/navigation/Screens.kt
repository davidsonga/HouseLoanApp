package com.example.flinccalculatoralpha.navigation

object Screens {
    const val onboardingScreen = "onboarding_screen"
    const val homeScreen = "home_screen"
    const val calculateScreen = "calculate_screen"
    const val summaryScreen = "summary_screen"
}